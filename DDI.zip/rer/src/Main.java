import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Main extends JFrame {
    private final JTextField nField = new JTextField();
    private final JTextField timeField = new JTextField();
    private final JTextField resultField = new JTextField();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Число N", "Время (сек)", "Получившееся число"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable table = new JTable(tableModel);

    public Main() {
        super("Результаты производительности");
        setupUi();
        setupActionsAndHotkeys();
    }

    private void setupUi() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(900, 500));

        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBorder(new EmptyBorder(12, 12, 12, 12));
        root.setBackground(new Color(245, 247, 250));
        setContentPane(root);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 216, 224)),
                new EmptyBorder(12, 12, 12, 12)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        addLabeledField(formPanel, gbc, 0, "Число N:", nField);
        addLabeledField(formPanel, gbc, 1, "Время (сек):", timeField);
        addLabeledField(formPanel, gbc, 2, "Получившееся число:", resultField);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttonPanel.setOpaque(false);
        JButton addButton = createButton("Добавить");
        JButton deleteButton = createButton("Удалить");
        JButton clearButton = createButton("Очистить");
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(buttonPanel, gbc);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowHeight(24);
        table.getTableHeader().setReorderingAllowed(false);
        table.setGridColor(new Color(219, 224, 230));
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(true);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(210, 216, 224)));

        root.add(formPanel, BorderLayout.NORTH);
        root.add(scrollPane, BorderLayout.CENTER);

        addButton.addActionListener(this::addRow);
        deleteButton.addActionListener(this::deleteRow);
        clearButton.addActionListener(this::clearInputs);
    }

    private void setupActionsAndHotkeys() {
        Action addAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addRow(e);
            }
        };
        Action deleteAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteRow(e);
            }
        };
        Action clearAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearInputs(e);
            }
        };

        JRootPane rootPane = getRootPane();
        InputMap inputMap = rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap actionMap = rootPane.getActionMap();

        inputMap.put(KeyStroke.getKeyStroke("control N"), "addRow");
        inputMap.put(KeyStroke.getKeyStroke("DELETE"), "deleteRow");
        inputMap.put(KeyStroke.getKeyStroke("BACK_SPACE"), "clearFields");

        actionMap.put("addRow", addAction);
        actionMap.put("deleteRow", deleteAction);
        actionMap.put("clearFields", clearAction);
    }

    private void addRow(ActionEvent event) {
        String nValue = nField.getText().trim();
        String timeValue = timeField.getText().trim();
        String resultValue = resultField.getText().trim();

        if (nValue.isEmpty() || timeValue.isEmpty() || resultValue.isEmpty()) {
            showWarning("Заполните все поля перед добавлением строки.");
            return;
        }

        tableModel.addRow(new Object[]{nValue, timeValue, resultValue});
        clearTextFields();
    }

    private void deleteRow(ActionEvent event) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            showWarning("Выберите строку в таблице для удаления.");
            return;
        }
        tableModel.removeRow(selectedRow);
    }

    private void clearInputs(ActionEvent event) {
        clearTextFields();
    }

    private void clearTextFields() {
        nField.setText("");
        timeField.setText("");
        resultField.setText("");
        nField.requestFocusInWindow();
    }

    private void addLabeledField(JPanel panel, GridBagConstraints gbc, int row, String labelText, JTextField field) {
        JLabel label = new JLabel(labelText);
        label.setForeground(new Color(33, 37, 41));

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.0;
        panel.add(label, gbc);

        field.setColumns(20);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 188, 196)),
                new EmptyBorder(6, 8, 6, 8)
        ));
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        panel.add(field, gbc);
    }

    private JButton createButton(String title) {
        JButton button = new JButton(title);
        button.setFocusPainted(false);
        button.setBackground(new Color(230, 236, 242));
        button.setForeground(new Color(33, 37, 41));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(172, 181, 191)),
                new EmptyBorder(6, 12, 6, 12)
        ));
        return button;
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Внимание", JOptionPane.WARNING_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main frame = new Main();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}